exports.REGION = 'eu-west-1'
exports.DRY_RUN = true
exports.REPO_TO_CLEAN = ['marketplace/be', 'marketplace/fe']
exports.REPO_AGE_THRESHOLD = 30
exports.REPO_FIRST_N_THRESHOLD = 3
exports.AWS_ACCOUNT_ID = 315671387076
